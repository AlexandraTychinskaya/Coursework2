﻿namespace coursework2
{
    partial class SaleDetailsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridViewSaleDetails = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dataGridViewSaleDetails).BeginInit();
            SuspendLayout();
            // 
            // dataGridViewSaleDetails
            // 
            dataGridViewSaleDetails.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllHeaders;
            dataGridViewSaleDetails.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewSaleDetails.Dock = DockStyle.Fill;
            dataGridViewSaleDetails.Location = new Point(0, 0);
            dataGridViewSaleDetails.Name = "dataGridViewSaleDetails";
            dataGridViewSaleDetails.RowHeadersWidth = 51;
            dataGridViewSaleDetails.Size = new Size(800, 450);
            dataGridViewSaleDetails.TabIndex = 0;
            dataGridViewSaleDetails.CellContentClick += dataGridViewSaleDetails_CellContentClick;
            // 
            // SaleDetailsForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(dataGridViewSaleDetails);
            Name = "SaleDetailsForm";
            Text = "SaleDetailsForm";
            ((System.ComponentModel.ISupportInitialize)dataGridViewSaleDetails).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dataGridViewSaleDetails;
    }
}
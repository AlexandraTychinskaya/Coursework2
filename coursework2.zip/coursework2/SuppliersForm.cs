﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace coursework2
{
    public partial class SuppliersForm : Form
    {
        public SuppliersForm()
        {
            InitializeComponent();
            LoadSuppliers();
        }
        private void LoadSuppliers()
        {
            List<Supplier> suppliers = DBDataAccess.GetAllSuppliers();
            dataGridViewSuppliers.DataSource = suppliers;
            // Текст в заголовках и ячейках посередине
            dataGridViewSuppliers.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewSuppliers.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            // Автоматическое растягивание колонок
            dataGridViewSuppliers.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            dataGridViewSuppliers.Columns["Id"].HeaderText = "ID";
            dataGridViewSuppliers.Columns["Name"].HeaderText = "Название";
            dataGridViewSuppliers.Columns["ManagerName"].HeaderText = "ФИО менеджера";
            dataGridViewSuppliers.Columns["PhoneNumber"].HeaderText = "Номер телефона";
            dataGridViewSuppliers.Columns["Email"].HeaderText = "Электронная почта";
        }
        private void dataGridViewSuppliers_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}

﻿namespace coursework2
{
    partial class MainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            menuStrip1 = new MenuStrip();
            операцииToolStripMenuItem = new ToolStripMenuItem();
            поставкиToolStripMenuItem = new ToolStripMenuItem();
            продажиToolStripMenuItem = new ToolStripMenuItem();
            отчётыToolStripMenuItem = new ToolStripMenuItem();
            поставкиЗаПериодToolStripMenuItem = new ToolStripMenuItem();
            продажиЗаПериодToolStripMenuItem = new ToolStripMenuItem();
            остаткиТоваровToolStripMenuItem = new ToolStripMenuItem();
            журналToolStripMenuItem = new ToolStripMenuItem();
            menuItemActionLog = new ToolStripMenuItem();
            окноToolStripMenuItem = new ToolStripMenuItem();
            сгруппироватьПоГоризонталиToolStripMenuItem = new ToolStripMenuItem();
            поГоризонталиToolStripMenuItem = new ToolStripMenuItem();
            поВертикалиToolStripMenuItem = new ToolStripMenuItem();
            каскадомToolStripMenuItem = new ToolStripMenuItem();
            закрытьВсеОкнаToolStripMenuItem = new ToolStripMenuItem();
            справкаToolStripMenuItem = new ToolStripMenuItem();
            оПрограммеToolStripMenuItem = new ToolStripMenuItem();
            горячиеКлавишиToolStripMenuItem = new ToolStripMenuItem();
            toolStrip1 = new ToolStrip();
            menuItemCategories = new ToolStripButton();
            menuItemProducts = new ToolStripButton();
            menuItemUsers = new ToolStripButton();
            menuItemSupplies = new ToolStripButton();
            menuItemSales = new ToolStripButton();
            toolStripButton6 = new ToolStripButton();
            menuItemManufacturers = new ToolStripButton();
            menuItemSuppliers = new ToolStripButton();
            statusStrip1 = new StatusStrip();
            toolStripStatusLabel1 = new ToolStripStatusLabel();
            menuStrip1.SuspendLayout();
            toolStrip1.SuspendLayout();
            statusStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.BackColor = Color.SteelBlue;
            menuStrip1.ImageScalingSize = new Size(20, 20);
            menuStrip1.Items.AddRange(new ToolStripItem[] { операцииToolStripMenuItem, отчётыToolStripMenuItem, журналToolStripMenuItem, окноToolStripMenuItem, справкаToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(1049, 28);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // операцииToolStripMenuItem
            // 
            операцииToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { поставкиToolStripMenuItem, продажиToolStripMenuItem });
            операцииToolStripMenuItem.ForeColor = SystemColors.ButtonHighlight;
            операцииToolStripMenuItem.Name = "операцииToolStripMenuItem";
            операцииToolStripMenuItem.Size = new Size(95, 24);
            операцииToolStripMenuItem.Text = "Операции";
            // 
            // поставкиToolStripMenuItem
            // 
            поставкиToolStripMenuItem.Name = "поставкиToolStripMenuItem";
            поставкиToolStripMenuItem.Size = new Size(157, 26);
            поставкиToolStripMenuItem.Text = "Поставки";
            // 
            // продажиToolStripMenuItem
            // 
            продажиToolStripMenuItem.Name = "продажиToolStripMenuItem";
            продажиToolStripMenuItem.Size = new Size(157, 26);
            продажиToolStripMenuItem.Text = "Продажи";
            // 
            // отчётыToolStripMenuItem
            // 
            отчётыToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { поставкиЗаПериодToolStripMenuItem, продажиЗаПериодToolStripMenuItem, остаткиТоваровToolStripMenuItem });
            отчётыToolStripMenuItem.ForeColor = SystemColors.ButtonHighlight;
            отчётыToolStripMenuItem.Name = "отчётыToolStripMenuItem";
            отчётыToolStripMenuItem.Size = new Size(73, 24);
            отчётыToolStripMenuItem.Text = "Отчёты";
            // 
            // поставкиЗаПериодToolStripMenuItem
            // 
            поставкиЗаПериодToolStripMenuItem.Name = "поставкиЗаПериодToolStripMenuItem";
            поставкиЗаПериодToolStripMenuItem.Size = new Size(232, 26);
            поставкиЗаПериодToolStripMenuItem.Text = "Поставки за период";
            // 
            // продажиЗаПериодToolStripMenuItem
            // 
            продажиЗаПериодToolStripMenuItem.Name = "продажиЗаПериодToolStripMenuItem";
            продажиЗаПериодToolStripMenuItem.Size = new Size(232, 26);
            продажиЗаПериодToolStripMenuItem.Text = "Продажи за период";
            // 
            // остаткиТоваровToolStripMenuItem
            // 
            остаткиТоваровToolStripMenuItem.Name = "остаткиТоваровToolStripMenuItem";
            остаткиТоваровToolStripMenuItem.Size = new Size(232, 26);
            остаткиТоваровToolStripMenuItem.Text = "Остатки товаров";
            // 
            // журналToolStripMenuItem
            // 
            журналToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { menuItemActionLog });
            журналToolStripMenuItem.ForeColor = SystemColors.ButtonHighlight;
            журналToolStripMenuItem.Name = "журналToolStripMenuItem";
            журналToolStripMenuItem.Size = new Size(77, 24);
            журналToolStripMenuItem.Text = "Журнал";
            // 
            // menuItemActionLog
            // 
            menuItemActionLog.Name = "menuItemActionLog";
            menuItemActionLog.Size = new Size(224, 26);
            menuItemActionLog.Text = "История действий";
            menuItemActionLog.Click += menuItemActionLog_Click;
            // 
            // окноToolStripMenuItem
            // 
            окноToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { сгруппироватьПоГоризонталиToolStripMenuItem, закрытьВсеОкнаToolStripMenuItem });
            окноToolStripMenuItem.ForeColor = SystemColors.ButtonHighlight;
            окноToolStripMenuItem.Name = "окноToolStripMenuItem";
            окноToolStripMenuItem.Size = new Size(59, 24);
            окноToolStripMenuItem.Text = "Окно";
            // 
            // сгруппироватьПоГоризонталиToolStripMenuItem
            // 
            сгруппироватьПоГоризонталиToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { поГоризонталиToolStripMenuItem, поВертикалиToolStripMenuItem, каскадомToolStripMenuItem });
            сгруппироватьПоГоризонталиToolStripMenuItem.Name = "сгруппироватьПоГоризонталиToolStripMenuItem";
            сгруппироватьПоГоризонталиToolStripMenuItem.Size = new Size(221, 26);
            сгруппироватьПоГоризонталиToolStripMenuItem.Text = "Упорядочить окна";
            сгруппироватьПоГоризонталиToolStripMenuItem.Click += сгруппироватьПоГоризонталиToolStripMenuItem_Click;
            // 
            // поГоризонталиToolStripMenuItem
            // 
            поГоризонталиToolStripMenuItem.Name = "поГоризонталиToolStripMenuItem";
            поГоризонталиToolStripMenuItem.Size = new Size(205, 26);
            поГоризонталиToolStripMenuItem.Text = "По горизонтали";
            // 
            // поВертикалиToolStripMenuItem
            // 
            поВертикалиToolStripMenuItem.Name = "поВертикалиToolStripMenuItem";
            поВертикалиToolStripMenuItem.Size = new Size(205, 26);
            поВертикалиToolStripMenuItem.Text = "По вертикали";
            // 
            // каскадомToolStripMenuItem
            // 
            каскадомToolStripMenuItem.Name = "каскадомToolStripMenuItem";
            каскадомToolStripMenuItem.Size = new Size(205, 26);
            каскадомToolStripMenuItem.Text = "Каскадом";
            // 
            // закрытьВсеОкнаToolStripMenuItem
            // 
            закрытьВсеОкнаToolStripMenuItem.Name = "закрытьВсеОкнаToolStripMenuItem";
            закрытьВсеОкнаToolStripMenuItem.Size = new Size(221, 26);
            закрытьВсеОкнаToolStripMenuItem.Text = "Закрыть все окна";
            // 
            // справкаToolStripMenuItem
            // 
            справкаToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { оПрограммеToolStripMenuItem, горячиеКлавишиToolStripMenuItem });
            справкаToolStripMenuItem.ForeColor = SystemColors.ButtonHighlight;
            справкаToolStripMenuItem.Name = "справкаToolStripMenuItem";
            справкаToolStripMenuItem.Size = new Size(81, 24);
            справкаToolStripMenuItem.Text = "Справка";
            // 
            // оПрограммеToolStripMenuItem
            // 
            оПрограммеToolStripMenuItem.Name = "оПрограммеToolStripMenuItem";
            оПрограммеToolStripMenuItem.Size = new Size(215, 26);
            оПрограммеToolStripMenuItem.Text = "О программе";
            // 
            // горячиеКлавишиToolStripMenuItem
            // 
            горячиеКлавишиToolStripMenuItem.Name = "горячиеКлавишиToolStripMenuItem";
            горячиеКлавишиToolStripMenuItem.Size = new Size(215, 26);
            горячиеКлавишиToolStripMenuItem.Text = "Горячие клавиши";
            // 
            // toolStrip1
            // 
            toolStrip1.BackColor = Color.LightBlue;
            toolStrip1.Dock = DockStyle.Left;
            toolStrip1.GripStyle = ToolStripGripStyle.Hidden;
            toolStrip1.ImageScalingSize = new Size(20, 20);
            toolStrip1.Items.AddRange(new ToolStripItem[] { menuItemCategories, menuItemProducts, menuItemUsers, menuItemSupplies, menuItemSales, toolStripButton6, menuItemManufacturers, menuItemSuppliers });
            toolStrip1.LayoutStyle = ToolStripLayoutStyle.VerticalStackWithOverflow;
            toolStrip1.Location = new Point(0, 28);
            toolStrip1.Name = "toolStrip1";
            toolStrip1.Size = new Size(124, 543);
            toolStrip1.TabIndex = 1;
            toolStrip1.Text = "toolStrip1";
            // 
            // menuItemCategories
            // 
            menuItemCategories.DisplayStyle = ToolStripItemDisplayStyle.Text;
            menuItemCategories.Image = (Image)resources.GetObject("menuItemCategories.Image");
            menuItemCategories.ImageTransparentColor = Color.Magenta;
            menuItemCategories.Name = "menuItemCategories";
            menuItemCategories.Size = new Size(121, 24);
            menuItemCategories.Text = "Категории";
            menuItemCategories.Click += menuItemCategories_Click;
            // 
            // menuItemProducts
            // 
            menuItemProducts.DisplayStyle = ToolStripItemDisplayStyle.Text;
            menuItemProducts.Image = (Image)resources.GetObject("menuItemProducts.Image");
            menuItemProducts.ImageTransparentColor = Color.Magenta;
            menuItemProducts.Name = "menuItemProducts";
            menuItemProducts.Size = new Size(121, 24);
            menuItemProducts.Text = "Товары";
            menuItemProducts.Click += menuItemProducts_Click;
            // 
            // menuItemUsers
            // 
            menuItemUsers.DisplayStyle = ToolStripItemDisplayStyle.Text;
            menuItemUsers.Image = (Image)resources.GetObject("menuItemUsers.Image");
            menuItemUsers.ImageTransparentColor = Color.Magenta;
            menuItemUsers.Name = "menuItemUsers";
            menuItemUsers.Size = new Size(121, 24);
            menuItemUsers.Text = "Пользователи";
            menuItemUsers.Click += menuItemUsers_Click;
            // 
            // menuItemSupplies
            // 
            menuItemSupplies.DisplayStyle = ToolStripItemDisplayStyle.Text;
            menuItemSupplies.Image = (Image)resources.GetObject("menuItemSupplies.Image");
            menuItemSupplies.ImageTransparentColor = Color.Magenta;
            menuItemSupplies.Name = "menuItemSupplies";
            menuItemSupplies.Size = new Size(121, 24);
            menuItemSupplies.Text = "Поставки";
            menuItemSupplies.Click += menuItemSupplies_Click;
            // 
            // menuItemSales
            // 
            menuItemSales.DisplayStyle = ToolStripItemDisplayStyle.Text;
            menuItemSales.Image = (Image)resources.GetObject("menuItemSales.Image");
            menuItemSales.ImageTransparentColor = Color.Magenta;
            menuItemSales.Name = "menuItemSales";
            menuItemSales.Size = new Size(121, 24);
            menuItemSales.Text = "Продажи";
            menuItemSales.Click += menuItemSales_Click;
            // 
            // toolStripButton6
            // 
            toolStripButton6.Alignment = ToolStripItemAlignment.Right;
            toolStripButton6.BackColor = Color.LightCyan;
            toolStripButton6.DisplayStyle = ToolStripItemDisplayStyle.Text;
            toolStripButton6.Image = (Image)resources.GetObject("toolStripButton6.Image");
            toolStripButton6.ImageTransparentColor = Color.Magenta;
            toolStripButton6.Name = "toolStripButton6";
            toolStripButton6.Size = new Size(121, 24);
            toolStripButton6.Text = "Выход";
            toolStripButton6.Click += toolStripButton6_Click;
            // 
            // menuItemManufacturers
            // 
            menuItemManufacturers.DisplayStyle = ToolStripItemDisplayStyle.Text;
            menuItemManufacturers.Image = (Image)resources.GetObject("menuItemManufacturers.Image");
            menuItemManufacturers.ImageTransparentColor = Color.Magenta;
            menuItemManufacturers.Name = "menuItemManufacturers";
            menuItemManufacturers.Size = new Size(121, 24);
            menuItemManufacturers.Text = "Производители";
            menuItemManufacturers.Click += menuItemManufacturers_Click;
            // 
            // menuItemSuppliers
            // 
            menuItemSuppliers.DisplayStyle = ToolStripItemDisplayStyle.Text;
            menuItemSuppliers.Image = (Image)resources.GetObject("menuItemSuppliers.Image");
            menuItemSuppliers.ImageTransparentColor = Color.Magenta;
            menuItemSuppliers.Name = "menuItemSuppliers";
            menuItemSuppliers.Size = new Size(121, 24);
            menuItemSuppliers.Text = "Поставщики";
            menuItemSuppliers.Click += menuItemSuppliers_Click;
            // 
            // statusStrip1
            // 
            statusStrip1.ImageScalingSize = new Size(20, 20);
            statusStrip1.Items.AddRange(new ToolStripItem[] { toolStripStatusLabel1 });
            statusStrip1.Location = new Point(124, 545);
            statusStrip1.Name = "statusStrip1";
            statusStrip1.Size = new Size(925, 26);
            statusStrip1.TabIndex = 2;
            statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            toolStripStatusLabel1.BackColor = Color.LightBlue;
            toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            toolStripStatusLabel1.Size = new Size(390, 20);
            toolStripStatusLabel1.Text = "Вы вошли как Иванов И.И., ваша роль: администратор";
            toolStripStatusLabel1.Click += toolStripStatusLabel1_Click;
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightCyan;
            ClientSize = new Size(1049, 571);
            Controls.Add(statusStrip1);
            Controls.Add(toolStrip1);
            Controls.Add(menuStrip1);
            IsMdiContainer = true;
            MainMenuStrip = menuStrip1;
            Name = "MainForm";
            Text = "Form1";
            Load += Form1_Load;
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            toolStrip1.ResumeLayout(false);
            toolStrip1.PerformLayout();
            statusStrip1.ResumeLayout(false);
            statusStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem окноToolStripMenuItem;
        private ToolStrip toolStrip1;
        private ToolStripButton menuItemSupplies;
        private ToolStripButton menuItemSales;
        private ToolStripButton menuItemProducts;
        private ToolStripButton toolStripButton6;
        private ToolStripMenuItem справкаToolStripMenuItem;
        private ToolStripMenuItem закрытьВсеОкнаToolStripMenuItem;
        private ToolStripMenuItem операцииToolStripMenuItem;
        private ToolStripMenuItem поставкиToolStripMenuItem;
        private ToolStripMenuItem продажиToolStripMenuItem;
        private ToolStripMenuItem оПрограммеToolStripMenuItem;
        private ToolStripMenuItem отчётыToolStripMenuItem;
        private ToolStripMenuItem поставкиЗаПериодToolStripMenuItem;
        private ToolStripMenuItem продажиЗаПериодToolStripMenuItem;
        private ToolStripMenuItem остаткиТоваровToolStripMenuItem;
        private ToolStripMenuItem сгруппироватьПоГоризонталиToolStripMenuItem;
        private ToolStripMenuItem поГоризонталиToolStripMenuItem;
        private ToolStripMenuItem поВертикалиToolStripMenuItem;
        private ToolStripMenuItem каскадомToolStripMenuItem;
        private ToolStripMenuItem горячиеКлавишиToolStripMenuItem;
        private ToolStripMenuItem журналToolStripMenuItem;
        private ToolStripMenuItem menuItemActionLog;
        private ToolStripButton menuItemCategories;
        private StatusStrip statusStrip1;
        private ToolStripStatusLabel toolStripStatusLabel1;
        private ToolStripButton menuItemUsers;
        private ToolStripButton menuItemManufacturers;
        private ToolStripButton menuItemSuppliers;
    }
}

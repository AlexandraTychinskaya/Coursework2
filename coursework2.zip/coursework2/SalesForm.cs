﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace coursework2
{
    public partial class SalesForm : Form
    {
        public SalesForm()
        {
            InitializeComponent();
            LoadSales();
        }
        private void LoadSales()
        {
            List<Sale> sales = DBDataAccess.GetAllSales();
            dataGridViewSales.DataSource = sales;
            // Текст в заголовках и ячейках посередине
            dataGridViewSales.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewSales.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            // Автоматическое растягивание колонок
            dataGridViewSales.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            dataGridViewSales.Columns["Id"].HeaderText = "ID";
            dataGridViewSales.Columns["SaleDate"].HeaderText = "Дата продажи";
            dataGridViewSales.Columns["UserId"].HeaderText = "ID пользователя";
        }
        private void dataGridViewSales_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridViewSales_CellDoubleClick(object sender, DataGridViewCellEventArgs e) //открываем состав продажи
        {
            if (e.RowIndex >= 0)
            {
                int saleId = (int)dataGridViewSales.Rows[e.RowIndex].Cells["Id"].Value;
                SaleDetailsForm detailsForm = new SaleDetailsForm(saleId);
                detailsForm.ShowDialog(); // модальное окно. пока оно открыто, блокируется взаимодействие с другими окнами
            }
        }
    }
}

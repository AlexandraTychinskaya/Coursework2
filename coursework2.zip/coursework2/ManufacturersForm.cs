﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace coursework2
{
    public partial class ManufacturersForm : Form
    {
        public ManufacturersForm()
        {
            InitializeComponent();
            LoadManufacturers();
        }
        private void LoadManufacturers()
        {
            List<Manufacturer> manufacturers = DBDataAccess.GetAllManufacturers();
            dataGridViewManufacturers.DataSource = manufacturers;
            // Текст в заголовках и ячейках посередине
            dataGridViewManufacturers.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewManufacturers.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            // Автоматическое растягивание колонок
            dataGridViewManufacturers.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            dataGridViewManufacturers.Columns["Id"].HeaderText = "ID";
            dataGridViewManufacturers.Columns["Name"].HeaderText = "Название";
            dataGridViewManufacturers.Columns["Country"].HeaderText = "Страна";
        }
        private void dataGridViewManufacturers_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}

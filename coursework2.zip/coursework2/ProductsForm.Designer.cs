﻿namespace coursework2
{
    partial class ProductsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ProductsForm));
            dataGridViewProducts = new DataGridView();
            toolStrip1 = new ToolStrip();
            actionsToolStripButton = new ToolStripDropDownButton();
            добавитьToolStripMenuItem = new ToolStripMenuItem();
            редактироватьToolStripMenuItem = new ToolStripMenuItem();
            удалитьToolStripMenuItem = new ToolStripMenuItem();
            filterToolStripButton = new ToolStripButton();
            searchToolStripButton1 = new ToolStripButton();
            ((System.ComponentModel.ISupportInitialize)dataGridViewProducts).BeginInit();
            toolStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // dataGridViewProducts
            // 
            dataGridViewProducts.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            dataGridViewProducts.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewProducts.Location = new Point(0, 30);
            dataGridViewProducts.Name = "dataGridViewProducts";
            dataGridViewProducts.RowHeadersWidth = 51;
            dataGridViewProducts.Size = new Size(800, 420);
            dataGridViewProducts.TabIndex = 0;
            dataGridViewProducts.CellEndEdit += dataGridViewProducts_CellEndEdit;
            dataGridViewProducts.RowValidating += dataGridViewProducts_RowValidating;
            dataGridViewProducts.UserDeletingRow += dataGridViewProducts_UserDeletingRow;
            // 
            // toolStrip1
            // 
            toolStrip1.ImageScalingSize = new Size(20, 20);
            toolStrip1.Items.AddRange(new ToolStripItem[] { actionsToolStripButton, filterToolStripButton, searchToolStripButton1 });
            toolStrip1.Location = new Point(0, 0);
            toolStrip1.Name = "toolStrip1";
            toolStrip1.Size = new Size(800, 27);
            toolStrip1.TabIndex = 1;
            toolStrip1.Text = "toolStrip1";
            // 
            // actionsToolStripButton
            // 
            actionsToolStripButton.DisplayStyle = ToolStripItemDisplayStyle.Text;
            actionsToolStripButton.DropDownItems.AddRange(new ToolStripItem[] { добавитьToolStripMenuItem, редактироватьToolStripMenuItem, удалитьToolStripMenuItem });
            actionsToolStripButton.Image = (Image)resources.GetObject("actionsToolStripButton.Image");
            actionsToolStripButton.ImageTransparentColor = Color.Magenta;
            actionsToolStripButton.Name = "actionsToolStripButton";
            actionsToolStripButton.Size = new Size(88, 24);
            actionsToolStripButton.Text = "Действия";
            // 
            // добавитьToolStripMenuItem
            // 
            добавитьToolStripMenuItem.Name = "добавитьToolStripMenuItem";
            добавитьToolStripMenuItem.Size = new Size(194, 26);
            добавитьToolStripMenuItem.Text = "Добавить";
            // 
            // редактироватьToolStripMenuItem
            // 
            редактироватьToolStripMenuItem.Name = "редактироватьToolStripMenuItem";
            редактироватьToolStripMenuItem.Size = new Size(194, 26);
            редактироватьToolStripMenuItem.Text = "Редактировать";
            // 
            // удалитьToolStripMenuItem
            // 
            удалитьToolStripMenuItem.Name = "удалитьToolStripMenuItem";
            удалитьToolStripMenuItem.Size = new Size(194, 26);
            удалитьToolStripMenuItem.Text = "Удалить";
            // 
            // filterToolStripButton
            // 
            filterToolStripButton.DisplayStyle = ToolStripItemDisplayStyle.Text;
            filterToolStripButton.Image = (Image)resources.GetObject("filterToolStripButton.Image");
            filterToolStripButton.ImageTransparentColor = Color.Magenta;
            filterToolStripButton.Name = "filterToolStripButton";
            filterToolStripButton.Size = new Size(64, 24);
            filterToolStripButton.Text = "Фильтр";
            // 
            // searchToolStripButton1
            // 
            searchToolStripButton1.DisplayStyle = ToolStripItemDisplayStyle.Text;
            searchToolStripButton1.Image = (Image)resources.GetObject("searchToolStripButton1.Image");
            searchToolStripButton1.ImageTransparentColor = Color.Magenta;
            searchToolStripButton1.Name = "searchToolStripButton1";
            searchToolStripButton1.Size = new Size(56, 24);
            searchToolStripButton1.Text = "Поиск";
            // 
            // ProductsForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(toolStrip1);
            Controls.Add(dataGridViewProducts);
            Name = "ProductsForm";
            Text = "ProductsForm";
            ((System.ComponentModel.ISupportInitialize)dataGridViewProducts).EndInit();
            toolStrip1.ResumeLayout(false);
            toolStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridViewProducts;
        private ToolStrip toolStrip1;
        private ToolStripButton filterToolStripButton;
        private ToolStripButton searchToolStripButton1;
        private ToolStripDropDownButton actionsToolStripButton;
        private ToolStripMenuItem добавитьToolStripMenuItem;
        private ToolStripMenuItem редактироватьToolStripMenuItem;
        private ToolStripMenuItem удалитьToolStripMenuItem;
    }
}
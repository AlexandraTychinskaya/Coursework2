﻿using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;

namespace coursework2
{
    public static class DBDataAccess
    {
        private static readonly string connectionString = "Data Source=localhost;Initial Catalog=stationery_store;Integrated Security=True;Encrypt=False";

        // Загрузка всех товаров
        public static List<Product> GetAllProducts()
        {
            List<Product> products = new List<Product>();

            string query = "SELECT * FROM [товары]";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    products.Add(new Product
                    {
                        Id = reader.GetInt32(0),
                        Name = reader.GetString(1),
                        Article = reader.GetString(2),
                        Barcode = reader.GetString(3),
                        ManufacturerId = reader.IsDBNull(4) ? null : reader.GetInt32(4),
                        RetailPrice = reader.GetDecimal(5),
                        PurchasePrice = reader.GetDecimal(6),
                        StockQuantity = reader.GetInt32(7),
                        ReceiptDate = reader.IsDBNull(8) ? null : reader.GetDateTime(8),
                        AccountingFormat = reader.GetString(9),
                        Status = reader.GetString(10),
                        CategoryId = reader.GetInt32(11)
                    });
                }
                reader.Close();
            }

            return products;
        }

        // ____________________________
        // ______ Products: CRUD ______
        // ____________________________

        // Добавление товара
        public static int AddProduct(Product product)
        {
            string query = @"INSERT INTO [товары] 
        ([название], [артикул], [штрихкод], [id_производителя], [цена_розничная], [цена_закупочная], 
         [количество_на_складе], [дата_поступления], [формат_учёта], [статус], [id_категории])
        OUTPUT INSERTED.[id]
        VALUES
        (@Name, @Article, @Barcode, @ManufacturerId, @RetailPrice, @PurchasePrice,
         @StockQuantity, @ReceiptDate, @AccountingFormat, @Status, @CategoryId)";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Name", product.Name ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@Article", product.Article ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@Barcode", product.Barcode ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@ManufacturerId", (object?)product.ManufacturerId ?? DBNull.Value);
                command.Parameters.AddWithValue("@RetailPrice", product.RetailPrice);
                command.Parameters.AddWithValue("@PurchasePrice", product.PurchasePrice);
                command.Parameters.AddWithValue("@StockQuantity", product.StockQuantity);
                command.Parameters.AddWithValue("@ReceiptDate", (object?)product.ReceiptDate ?? DBNull.Value);
                command.Parameters.AddWithValue("@AccountingFormat", product.AccountingFormat ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@Status", product.Status ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@CategoryId", product.CategoryId);

                connection.Open();
                int newId = (int)command.ExecuteScalar();
                return newId;
            }
        }


        // Обновление товара
        public static void UpdateProduct(Product product)
        {
            string query = @"UPDATE [товары] SET 
        [название] = @Name,
        [артикул] = @Article,
        [штрихкод] = @Barcode,
        [id_производителя] = @ManufacturerId,
        [цена_розничная] = @RetailPrice,
        [цена_закупочная] = @PurchasePrice,
        [количество_на_складе] = @StockQuantity,
        [дата_поступления] = @ReceiptDate,
        [формат_учёта] = @AccountingFormat,
        [статус] = @Status,
        [id_категории] = @CategoryId
        WHERE [id] = @Id";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Id", product.Id);
                command.Parameters.AddWithValue("@Name", product.Name ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@Article", product.Article ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@Barcode", product.Barcode ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@ManufacturerId", (object?)product.ManufacturerId ?? DBNull.Value);
                command.Parameters.AddWithValue("@RetailPrice", product.RetailPrice);
                command.Parameters.AddWithValue("@PurchasePrice", product.PurchasePrice);
                command.Parameters.AddWithValue("@StockQuantity", product.StockQuantity);
                command.Parameters.AddWithValue("@ReceiptDate", (object?)product.ReceiptDate ?? DBNull.Value);
                command.Parameters.AddWithValue("@AccountingFormat", product.AccountingFormat ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@Status", product.Status ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@CategoryId", product.CategoryId);

                connection.Open();
                command.ExecuteNonQuery();
            }
        }

        // Удаление товара
        public static void DeleteProduct(int id)
        {
            string query = "DELETE FROM [товары] WHERE [id] = @Id";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Id", id);

                connection.Open();
                command.ExecuteNonQuery();
            }
        }

        //______________________________________________________________________________________________
        //Загрузка всех категорий
        public static List<Category> GetAllCategories()
        {
            List<Category> categories = new List<Category>();
            string query = "SELECT * FROM [категории]";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    categories.Add(new Category
                    {
                        Id = reader.GetInt32(0),
                        Name = reader.GetString(1)
                    });
                }
                reader.Close();
            }

            return categories;
        }
        
        //______________________________________________________________________________________________
        // Загрузка всех пользователей
        public static List<User> GetAllUsers()
        {
            List<User> users = new List<User>();
            string query = "SELECT * FROM [пользователи]";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    users.Add(new User
                    {
                        Id = reader.GetInt32(0),
                        FullName = reader.GetString(1),
                        Login = reader.GetString(2),
                        Password = reader.GetString(3),
                        Role = reader.GetString(4),
                        RegistrationDate = reader.GetDateTime(5),
                        Status = reader.GetString(6)
                    });
                }
                reader.Close();
            }

            return users;
        }

        //______________________________________________________________________________________________
        // Загрузка всех поставщиков
        public static List<Supplier> GetAllSuppliers()
        {
            List<Supplier> suppliers = new List<Supplier>();
            string query = "SELECT * FROM [поставщики]";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    suppliers.Add(new Supplier
                    {
                        Id = reader.GetInt32(0),
                        Name = reader.GetString(1),
                        ManagerName = reader.GetString(2),
                        PhoneNumber = reader.GetString(3),
                        Email = reader.GetString(4)
                    });
                }
                reader.Close();
            }

            return suppliers;
        }

        //______________________________________________________________________________________________
        // Загрузка всех производителей
        public static List<Manufacturer> GetAllManufacturers()
        {
            List<Manufacturer> manufacturers = new List<Manufacturer>();
            string query = "SELECT * FROM [производители]";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    manufacturers.Add(new Manufacturer
                    {
                        Id = reader.GetInt32(0),
                        Name = reader.GetString(1),
                        Country = reader.GetString(2)
                    });
                }
                reader.Close();
            }

            return manufacturers;
        }

        //______________________________________________________________________________________________
        // Загрузка всех продаж
        public static List<Sale> GetAllSales()
        {
            List<Sale> sales = new List<Sale>();
            string query = "SELECT * FROM [продажи]";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    sales.Add(new Sale
                    {
                        Id = reader.GetInt32(0),
                        SaleDate = reader.GetDateTime(1),
                        UserId = reader.GetInt32(2)
                    });
                }
                reader.Close();
            }

            return sales;
        }

        //______________________________________________________________________________________________
        // Загрузка всех структур продаж
        public static List<SaleStructure> GetAllSaleStructures()
        {
            List<SaleStructure> saleStructures = new List<SaleStructure>();
            string query = "SELECT * FROM [состав_продажи]";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    saleStructures.Add(new SaleStructure
                    {
                        Id = reader.GetInt32(0),
                        SaleId = reader.GetInt32(1),
                        ProductId = reader.GetInt32(2),
                        Quantity = reader.GetInt32(3),
                        CurrentSalePrice = reader.GetDecimal(4)
                    });
                }
                reader.Close();
            }

            return saleStructures;
        }
        public static List<SaleStructure> GetSaleStructureBySaleId(int saleId)
        {
            List<SaleStructure> saleStructures = new List<SaleStructure>();
            string query = "SELECT * FROM [состав_продажи] WHERE [id_продажи] = @saleId";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@saleId", saleId);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    saleStructures.Add(new SaleStructure
                    {
                        Id = reader.GetInt32(0),
                        SaleId = reader.GetInt32(1),
                        ProductId = reader.GetInt32(2),
                        Quantity = reader.GetInt32(3),
                        CurrentSalePrice = reader.GetDecimal(4)
                    });
                }
                reader.Close();
            }

            return saleStructures;
        }

        //______________________________________________________________________________________________
        // Загрузка всех поставок
        public static List<Supply> GetAllSupplies()
        {
            List<Supply> supplies = new List<Supply>();
            string query = "SELECT * FROM [поставки]";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    supplies.Add(new Supply
                    {
                        Id = reader.GetInt32(0),
                        DeliveryDate = reader.GetDateTime(1),
                        UserId = reader.GetInt32(2),
                        SupplierId = reader.GetInt32(3)
                    });
                }
                reader.Close();
            }

            return supplies;
        }

        //______________________________________________________________________________________________
        // Загрузка всех структур поставок
        public static List<SupplyStructure> GetAllSupplyStructures()
        {
            List<SupplyStructure> supplyStructures = new List<SupplyStructure>();
            string query = "SELECT * FROM [состав_поставки]";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    supplyStructures.Add(new SupplyStructure
                    {
                        Id = reader.GetInt32(0),
                        SupplyId = reader.GetInt32(1),
                        ProductId = reader.GetInt32(2),
                        Quantity = reader.GetInt32(3),
                        CurrentPurchasePrice = reader.GetDecimal(4)
                    });
                }
                reader.Close();
            }

            return supplyStructures;
        }
        public static List<SupplyStructure> GetSupplyStructureBySupplyId(int supplyId)
        {
            List<SupplyStructure> structures = new List<SupplyStructure>();
            string query = "SELECT * FROM [состав_поставки] WHERE [id_поставки] = @supplyId";


            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@supplyId", supplyId);

                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    structures.Add(new SupplyStructure
                    {
                        Id = reader.GetInt32(0),
                        SupplyId = reader.GetInt32(1),
                        ProductId = reader.GetInt32(2),
                        Quantity = reader.GetInt32(3),
                        CurrentPurchasePrice = reader.GetDecimal(4)
                    });
                }

                reader.Close();
            }

            return structures;
        }

        //______________________________________________________________________________________________
        // Загрузка всего журнала действий
        public static List<ActionLog> GetAllActionLogs()
        {
            List<ActionLog> logs = new List<ActionLog>();
            string query = "SELECT * FROM [история_действий]";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    logs.Add(new ActionLog
                    {
                        Id = reader.GetInt32(0),
                        UserId = reader.GetInt32(1),
                        Date = reader.GetDateTime(2),
                        Action = reader.GetString(3),
                        Table = reader.GetString(4),
                        RowId = reader.GetInt32(5),
                        Description = reader.GetString(6)
                    });
                }
                reader.Close();
            }

            return logs;
        }

    }
}



namespace coursework2
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if (DBConnection.TestConnection())
            {
                MessageBox.Show("����������� �������!");
            }
            else
            {
                MessageBox.Show("�� ������� ������������ � ���� ������.");
            }
        }

        private void ��������������������������ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void toolStripButton6_Click(object sender, EventArgs e)
        {

        }

        private void toolStripStatusLabel1_Click(object sender, EventArgs e)
        {

        }


        private void menuItemUsers_Click(object sender, EventArgs e)
        {
            UsersForm usersForm = new UsersForm();
            usersForm.MdiParent = this; //usersForm ��������� ��� ����� (MainForm)
            usersForm.WindowState = FormWindowState.Maximized; // UsersForm �� ���� �����
            usersForm.Show();
        }

        private void menuItemCategories_Click(object sender, EventArgs e)
        {
            CategoriesForm categoriesForm = new CategoriesForm();
            categoriesForm.MdiParent = this;
            categoriesForm.WindowState = FormWindowState.Maximized; // CategoriesForm �� ���� �����
            categoriesForm.Show();
        }

        private void menuItemProducts_Click(object sender, EventArgs e)
        {
            ProductsForm productsForm = new ProductsForm();
            productsForm.MdiParent = this;
            productsForm.WindowState = FormWindowState.Maximized;
            productsForm.Show();
        }

        private void menuItemManufacturers_Click(object sender, EventArgs e)
        {
            ManufacturersForm manufacturersForm = new ManufacturersForm();
            manufacturersForm.MdiParent = this;
            manufacturersForm.WindowState = FormWindowState.Maximized;
            manufacturersForm.Show();
        }

        private void menuItemSuppliers_Click(object sender, EventArgs e)
        {
            SuppliersForm suppliersForm = new SuppliersForm();
            suppliersForm.MdiParent = this;
            suppliersForm.WindowState = FormWindowState.Maximized;
            suppliersForm.Show();
        }

        private void menuItemSales_Click(object sender, EventArgs e)
        {
            SalesForm salesForm = new SalesForm();
            salesForm.MdiParent = this;
            salesForm.WindowState = FormWindowState.Maximized;
            salesForm.Show();
        }

        private void menuItemSupplies_Click(object sender, EventArgs e)
        {
            SuppliesForm suppliesForm = new SuppliesForm();
            suppliesForm.MdiParent = this;
            suppliesForm.WindowState = FormWindowState.Maximized;
            suppliesForm.Show();
        }

        private void menuItemActionLog_Click(object sender, EventArgs e)
        {
            ActionLogForm actionLogForm = new ActionLogForm();
            actionLogForm.MdiParent = this;
            actionLogForm.WindowState = FormWindowState.Maximized;
            actionLogForm.Show();
        }
    }
}

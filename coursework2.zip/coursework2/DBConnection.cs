﻿using System;
using Microsoft.Data.SqlClient;

namespace coursework2
{
    internal static class DBConnection
    {
        private static string connectionString = "Data Source=localhost;Initial Catalog=stationery_store;Integrated Security=True;Encrypt=False";
        public static bool TestConnection()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    return true; // Успешное подключение
                }
            }
            catch (SqlException ex)
            {
                System.Windows.Forms.MessageBox.Show("Ошибка подключения: " + ex.Message);
                return false;
            }
        }
    }
}

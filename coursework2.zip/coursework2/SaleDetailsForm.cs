﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace coursework2
{
    public partial class SaleDetailsForm : Form
    {
        private int saleId;
        public SaleDetailsForm(int saleId)
        {
            InitializeComponent();
            this.saleId = saleId;
            LoadSaleStructure();
        }
        private void LoadSaleStructure()
        {
            List<SaleStructure> structure = DBDataAccess.GetSaleStructureBySaleId(saleId);
            dataGridViewSaleDetails.DataSource = structure;

            // Текст в заголовках и ячейках посередине
            dataGridViewSaleDetails.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            // Автоматическое растягивание колонок
            dataGridViewSaleDetails.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewSaleDetails.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            dataGridViewSaleDetails.Columns["Id"].Visible = false;
            dataGridViewSaleDetails.Columns["SaleId"].Visible = false;
            dataGridViewSaleDetails.Columns["ProductId"].HeaderText = "Товар";
            dataGridViewSaleDetails.Columns["Quantity"].HeaderText = "Количество";
            dataGridViewSaleDetails.Columns["CurrentSalePrice"].HeaderText = "Цена продажи";
        }
        private void dataGridViewSaleDetails_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}

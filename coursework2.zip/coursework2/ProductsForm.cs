﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace coursework2
{
    public partial class ProductsForm : Form
    {
        public ProductsForm()
        {
            InitializeComponent();
            LoadProducts();
        }
        private void LoadProducts()
        {
            BindingList<Product> products = new BindingList<Product>(DBDataAccess.GetAllProducts());
            dataGridViewProducts.DataSource = products;

            dataGridViewProducts.AllowUserToAddRows = true;
            dataGridViewProducts.AllowUserToDeleteRows = true;
            dataGridViewProducts.ReadOnly = false;
            dataGridViewProducts.EditMode = DataGridViewEditMode.EditOnEnter;
            dataGridViewProducts.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            dataGridViewProducts.DataSource = products;
            // Текст в заголовках и ячейках посередине
            dataGridViewProducts.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewProducts.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            // Автоматическое растягивание колонок
            dataGridViewProducts.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            dataGridViewProducts.Columns["Id"].HeaderText = "ID";
            dataGridViewProducts.Columns["Name"].HeaderText = "Название";
            dataGridViewProducts.Columns["Article"].HeaderText = "Артикул";
            dataGridViewProducts.Columns["Barcode"].HeaderText = "Штрихкод";
            dataGridViewProducts.Columns["ManufacturerId"].HeaderText = "ID производителя";
            dataGridViewProducts.Columns["RetailPrice"].HeaderText = "Цена розничная";
            dataGridViewProducts.Columns["PurchasePrice"].HeaderText = "Цена закупочная";
            dataGridViewProducts.Columns["StockQuantity"].HeaderText = "Количество на складе";
            dataGridViewProducts.Columns["ReceiptDate"].HeaderText = "Дата поступления";
            dataGridViewProducts.Columns["AccountingFormat"].HeaderText = "Формат учёта";
            dataGridViewProducts.Columns["Status"].HeaderText = "Статус";
            dataGridViewProducts.Columns["CategoryId"].HeaderText = "ID категории";
        }

        private void dataGridViewProducts_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            var row = dataGridViewProducts.Rows[e.RowIndex];

            if (row.IsNewRow || row.Cells["Id"].Value == null || row.Cells["Id"].Value == DBNull.Value)
                return; // строка новая, а не редактируемая существующая

            int id = Convert.ToInt32(row.Cells["Id"].Value);

            Product updatedProduct = new Product
            {
                Id = id,
                Name = row.Cells["Name"].Value?.ToString(),
                Article = row.Cells["Article"].Value?.ToString(),
                Barcode = row.Cells["Barcode"].Value?.ToString(),
                ManufacturerId = row.Cells["ManufacturerId"].Value == null ? null : Convert.ToInt32(row.Cells["ManufacturerId"].Value),
                RetailPrice = Convert.ToDecimal(row.Cells["RetailPrice"].Value),
                PurchasePrice = Convert.ToDecimal(row.Cells["PurchasePrice"].Value),
                StockQuantity = Convert.ToInt32(row.Cells["StockQuantity"].Value),
                ReceiptDate = row.Cells["ReceiptDate"].Value == null ? null : Convert.ToDateTime(row.Cells["ReceiptDate"].Value),
                AccountingFormat = row.Cells["AccountingFormat"].Value?.ToString(),
                Status = row.Cells["Status"].Value?.ToString(),
                CategoryId = Convert.ToInt32(row.Cells["CategoryId"].Value)
            };

            DBDataAccess.UpdateProduct(updatedProduct);
        }

        private void dataGridViewProducts_RowValidating(object sender, DataGridViewCellCancelEventArgs e)
        {
            var row = dataGridViewProducts.Rows[e.RowIndex];
            if (row.IsNewRow) return;

            // Проверка: строка ещё не сохранена (ID нет)
            if (row.Cells["Id"].Value == null || row.Cells["Id"].Value == DBNull.Value)
            {
                try
                {
                    var newProduct = new Product
                    {
                        Name = row.Cells["Name"].Value?.ToString(),
                        Article = row.Cells["Article"].Value?.ToString(),
                        Barcode = row.Cells["Barcode"].Value?.ToString(),
                        ManufacturerId = row.Cells["ManufacturerId"].Value == null ? null : Convert.ToInt32(row.Cells["ManufacturerId"].Value),
                        RetailPrice = decimal.TryParse(row.Cells["RetailPrice"].Value?.ToString(), out decimal r) ? r : 0,
                        PurchasePrice = decimal.TryParse(row.Cells["PurchasePrice"].Value?.ToString(), out decimal p) ? p : 0,
                        StockQuantity = int.TryParse(row.Cells["StockQuantity"].Value?.ToString(), out int s) ? s : 0,
                        ReceiptDate = DateTime.TryParse(row.Cells["ReceiptDate"].Value?.ToString(), out DateTime d) ? d : null,
                        AccountingFormat = row.Cells["AccountingFormat"].Value?.ToString(),
                        Status = row.Cells["Status"].Value?.ToString(),
                        CategoryId = int.TryParse(row.Cells["CategoryId"].Value?.ToString(), out int c) ? c : 1 // подставь дефолт
                    };

                    int newId = DBDataAccess.AddProduct(newProduct);
                    row.Cells["Id"].Value = newId;

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при добавлении товара: " + ex.Message);
                    e.Cancel = true;
                }
            }
        }


        private void dataGridViewProducts_UserDeletingRow(object sender, DataGridViewRowCancelEventArgs e)
        {
            if (e.Row.Cells["Id"].Value == null || e.Row.Cells["Id"].Value == DBNull.Value)
                return;

            int id = Convert.ToInt32(e.Row.Cells["Id"].Value);

            var confirm = MessageBox.Show("Удалить товар?", "Подтверждение", MessageBoxButtons.YesNo);
            if (confirm != DialogResult.Yes)
            {
                e.Cancel = true;
                return;
            }

            DBDataAccess.DeleteProduct(id);
        }

    }
}

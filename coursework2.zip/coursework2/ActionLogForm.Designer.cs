﻿namespace coursework2
{
    partial class ActionLogForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridViewActionLog = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dataGridViewActionLog).BeginInit();
            SuspendLayout();
            // 
            // dataGridViewActionLog
            // 
            dataGridViewActionLog.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewActionLog.Dock = DockStyle.Fill;
            dataGridViewActionLog.Location = new Point(0, 0);
            dataGridViewActionLog.Name = "dataGridViewActionLog";
            dataGridViewActionLog.RowHeadersWidth = 51;
            dataGridViewActionLog.Size = new Size(800, 450);
            dataGridViewActionLog.TabIndex = 0;
            dataGridViewActionLog.CellContentClick += dataGridViewActionLog_CellContentClick;
            // 
            // ActionLogForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(dataGridViewActionLog);
            Name = "ActionLogForm";
            Text = "ActionLogForm";
            ((System.ComponentModel.ISupportInitialize)dataGridViewActionLog).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dataGridViewActionLog;
    }
}
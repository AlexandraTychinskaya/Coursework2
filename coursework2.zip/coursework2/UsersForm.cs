﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace coursework2
{
    public partial class UsersForm : Form
    {
        public UsersForm()
        {
            InitializeComponent();
            LoadUsers(); // Загрузка пользователей при инициализации формы
        }
        private void LoadUsers()
        {
            List<User> users = DBDataAccess.GetAllUsers();
            dataGridViewUsers.DataSource = users;
            // Текст в заголовках и ячейках посередине
            dataGridViewUsers.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewUsers.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            // Автоматическое растягивание колонок
            dataGridViewUsers.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            dataGridViewUsers.Columns["Id"].HeaderText = "ID";
            dataGridViewUsers.Columns["FullName"].HeaderText = "ФИО";
            dataGridViewUsers.Columns["Login"].HeaderText = "Логин";
            dataGridViewUsers.Columns["Password"].HeaderText = "Пароль";
            dataGridViewUsers.Columns["Role"].HeaderText = "Роль";
            dataGridViewUsers.Columns["RegistrationDate"].HeaderText = "Дата регистрации";
            dataGridViewUsers.Columns["Status"].HeaderText = "Статус";

        }
        private void UsersForm_Load(object sender, EventArgs e)
        {

        }

        private void dataGridViewUsers_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}

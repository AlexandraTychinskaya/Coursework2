﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace coursework2
{
    public partial class CategoriesForm : Form
    {
        public CategoriesForm()
        {
            InitializeComponent();
            LoadCategories();
        }
        private void LoadCategories()
        {
            List<Category> categories = DBDataAccess.GetAllCategories();
            dataGridViewCategories.DataSource = categories;
            // Текст в заголовках и ячейках посередине
            dataGridViewCategories.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCategories.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            // Автоматическое растягивание колонок
            dataGridViewCategories.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            dataGridViewCategories.Columns["Id"].HeaderText = "ID";
            dataGridViewCategories.Columns["Name"].HeaderText = "Наименование";
        }
        private void dataGridViewCategories_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}

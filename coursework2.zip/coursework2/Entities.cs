﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
 * В Entities.cs хранятся классы - сущности бд.
 * В каждом классе свойства - поля сущностей бд.
*/
namespace coursework2
{
    public class Product
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Article { get; set; }
        public string Barcode { get; set; }
        public int? ManufacturerId { get; set; }
        public decimal RetailPrice { get; set; }
        public decimal PurchasePrice { get; set; }
        public int StockQuantity { get; set; }
        public DateTime? ReceiptDate { get; set; }
        public string AccountingFormat { get; set; }
        public string Status { get; set; }
        public int CategoryId { get; set; }
    }

    public class Category
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }

    public class User
    {
        public int Id { get; set; }
        public string FullName { get; set; }
        public string Login { get; set; }
        public string Password { get; set; }
        public string Role { get; set; }
        public DateTime RegistrationDate { get; set; }
        public string Status { get; set; }
    }

    public class Supplier
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string ManagerName { get; set; }
        public string PhoneNumber { get; set; }
        public string Email { get; set; }
    }

    public class Manufacturer
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Country { get; set; }
    }

    public class Supply
    {
        public int Id { get; set; }
        public DateTime DeliveryDate { get; set; }
        public int UserId { get; set; }
        public int SupplierId { get; set; }
    }

    public class Sale
    {
        public int Id { get; set; }
        public DateTime SaleDate { get; set; }
        public int UserId { get; set; }
    }

    public class SupplyStructure
    {
        public int Id { get; set; }
        public int SupplyId { get; set; }
        public int ProductId { get; set; }
        public int Quantity { get; set; }
        public decimal CurrentPurchasePrice { get; set; }
    }

    public class SaleStructure
    {
        public int Id { get; set; }
        public int SaleId { get; set; }
        public int ProductId { get; set; }
        public int Quantity { get; set; }
        public decimal CurrentSalePrice { get; set; }
    }

    public class ActionLog
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public DateTime Date { get; set; }
        public string Action { get; set; }
        public string Table { get; set; }
        public int RowId { get; set; }
        public string Description { get; set; }
    }
}


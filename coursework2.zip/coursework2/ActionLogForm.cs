﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace coursework2
{
    public partial class ActionLogForm : Form
    {
        public ActionLogForm()
        {
            InitializeComponent();
            LoadActionLog();
        }
        private void LoadActionLog()
        {
            List<ActionLog> actionLogs = DBDataAccess.GetAllActionLogs();
            dataGridViewActionLog.DataSource = actionLogs;
            // Текст в заголовках и ячейках посередине
            dataGridViewActionLog.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewActionLog.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            // Автоматическое растягивание колонок
            dataGridViewActionLog.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            dataGridViewActionLog.Columns["Id"].HeaderText = "ID";
            dataGridViewActionLog.Columns["UserId"].HeaderText = "ID пользователя";
            dataGridViewActionLog.Columns["Date"].HeaderText = "Дата";
            dataGridViewActionLog.Columns["Action"].HeaderText = "Действие";
            dataGridViewActionLog.Columns["Table"].HeaderText = "Таблица";
            dataGridViewActionLog.Columns["RowId"].HeaderText = "ID строки";
            dataGridViewActionLog.Columns["Description"].HeaderText = "Описание";
        }
        private void dataGridViewActionLog_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}

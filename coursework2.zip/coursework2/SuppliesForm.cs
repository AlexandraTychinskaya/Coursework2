﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace coursework2
{
    public partial class SuppliesForm : Form
    {
        public SuppliesForm()
        {
            InitializeComponent();
            LoadSupplies();
        }
        private void LoadSupplies()
        {
            List<Supply> supplies = DBDataAccess.GetAllSupplies();
            dataGridViewSupplies.DataSource = supplies;
            // Текст в заголовках и ячейках посередине
            dataGridViewSupplies.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewSupplies.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            // Автоматическое растягивание колонок
            dataGridViewSupplies.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            dataGridViewSupplies.Columns["Id"].HeaderText = "ID";
            dataGridViewSupplies.Columns["DeliveryDate"].HeaderText = "Дата поставки";
            dataGridViewSupplies.Columns["UserId"].HeaderText = "ID пользователя";
            dataGridViewSupplies.Columns["SupplierId"].HeaderText = "ID поставщика";
        }
        private void dataGridViewSupplies_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridViewSupplies_CellDoubleClick(object sender, DataGridViewCellEventArgs e) //открываем состав поставки
        {
            if (e.RowIndex >= 0)
            {
                int supplyId = (int)dataGridViewSupplies.Rows[e.RowIndex].Cells["Id"].Value;
                SupplyDetailsForm detailsForm = new SupplyDetailsForm(supplyId);
                detailsForm.ShowDialog(); // модальное окно. пока оно открыто, блокируется взаимодействие с другими окнами
            }
        }
    }
}

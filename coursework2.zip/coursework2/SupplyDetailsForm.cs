﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace coursework2
{
    public partial class SupplyDetailsForm : Form
    {
        private int supplyId;
        public SupplyDetailsForm(int supplyId)
        {
            InitializeComponent();
            LoadSupplyStructure();
            this.supplyId = supplyId;
        }
        private void LoadSupplyStructure()
        {
            List<SupplyStructure> structure = DBDataAccess.GetSupplyStructureBySupplyId(supplyId);
            dataGridViewSupplyDetails.DataSource = structure;
            // Текст в заголовках и ячейках посередине
            dataGridViewSupplyDetails.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            // Автоматическое растягивание колонок
            dataGridViewSupplyDetails.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewSupplyDetails.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            dataGridViewSupplyDetails.Columns["Id"].Visible = false;
            dataGridViewSupplyDetails.Columns["SupplyId"].Visible = false;
            dataGridViewSupplyDetails.Columns["ProductId"].HeaderText = "Товар";
            dataGridViewSupplyDetails.Columns["Quantity"].HeaderText = "Количество";
            dataGridViewSupplyDetails.Columns["CurrentPurchasePrice"].HeaderText = "Закупочная цена";
        }
        private void dataGridViewSupplyDetails_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
